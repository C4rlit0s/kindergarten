<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}
$options = array(
	'link' => array(
		'type'  => 'text',
		'label' => __( 'Link', 'the-core' ),
		'value' => '',
		'desc'  => __( 'Enter the link', 'the-core' )
	)
);