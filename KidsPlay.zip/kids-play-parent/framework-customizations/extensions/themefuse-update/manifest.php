<?php if (!defined('FW')) die('Forbidden');

$manifest = array();

$manifest['standalone'] = true;
$manifest['version']    = '1.0.0';
