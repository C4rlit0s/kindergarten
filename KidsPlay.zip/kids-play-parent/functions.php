<?php if ( ! defined( 'WP_DEBUG' ) ) {
	die( 'Direct access forbidden.' );
}

include_once get_template_directory() . '/theme-includes/init.php';
