<?php
/**
 * The template for displaying Search Results pages
 */
?>
<?php get_template_part( 'archive' ); ?>