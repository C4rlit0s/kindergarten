/* Single Image */
/* -------------------------------------------------- */
.fw-single-image.fw-single-image-left {
  float: left;
  margin-right: 30px;
}
.fw-single-image.fw-single-image-right {
  float: right;
  margin-left: 30px;
}
.fw-single-image.fw-single-image-center {
  display: block;
  margin-right: auto;
  margin-left: auto;
}
