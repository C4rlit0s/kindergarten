/* Woocommerce Widget Layout */
/* -------------------------------------------------- */
.woocommerce.widget .star-rating {
  color: <?php echo esc_js($the_core_less_variables['theme-color-5']); ?>;
}

/* Woocommerce Widget Product Categories */
/* -------------------------------------------------- */
/* style for this widget find in file widget-categories.css */

/* Woocommerce Widget Tag Cloud */
/* -------------------------------------------------- */
/* style for this widget find in file widget-tagcloud.css */
