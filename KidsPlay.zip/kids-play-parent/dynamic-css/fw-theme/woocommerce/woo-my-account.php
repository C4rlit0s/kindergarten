/* Woocommerce My Account */
/* -------------------------------------------------- */
table.my_account_orders {
  font-size: .85em;
}
table.my_account_orders td,
table.my_account_orders th {
  padding: 4px 8px;
  vertical-align: middle;
}
table.my_account_orders .button {
  white-space: nowrap;
}
table.my_account_orders .order-actions {
  text-align: right;
}
table.my_account_orders .order-actions .button {
  margin: .125em 0 .125em .25em;
}
