.widget_course_syllabus .llms-lesson-complete.done {
    color: <?php echo esc_js($the_core_less_variables['theme-color-1']); ?>;
}
.llms-widget-syllabus .section-title {
    color: <?php echo esc_js($the_core_less_variables['fw-widget-inner-title-color']); ?>;
}