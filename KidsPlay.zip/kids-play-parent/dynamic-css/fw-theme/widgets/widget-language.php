/* Widget Language Switcher */
.widget_fw_language_switcher_widget ul li img {
	position: relative;
	top: -0.1em;
}