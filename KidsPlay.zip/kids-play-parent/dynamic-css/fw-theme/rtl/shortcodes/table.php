/* Table RTL */
/* -------------------------------------------------- */
.rtl .fw-table .table-col-desc {
  text-align: right;
}
