/* Gallery RTL */
/* -------------------------------------------------- */
.rtl .fw-gallery.fw-gallery-type1 .fw-gallery-image.fw-block-image-parent,
.rtl .fw-gallery.fw-gallery-type1 .fw-gallery-image.fw-block-image-parent .fw-overlay-title,
.rtl .fw-gallery.fw-gallery-type1 .fw-gallery-image.fw-block-image-parent .fw-overlay-description,
.rtl .fw-gallery.fw-gallery-type4 .fw-block-image-overlay .fw-icell,
.rtl .fw-gallery.fw-gallery-type4 .fw-block-image-overlay .fw-icell .fw-overlay-title,
.rtl .fw-gallery.fw-gallery-type4 .fw-block-image-overlay .fw-icell .fw-overlay-description {
  text-align: right;
}
