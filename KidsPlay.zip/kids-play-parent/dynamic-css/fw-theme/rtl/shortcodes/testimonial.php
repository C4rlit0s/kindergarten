/* Testimonials RTL */
/* -------------------------------------------------- */
.rtl .fw-testimonials {
  direction: <?php echo esc_js($the_core_less_variables['ltr-direction']); ?>;
}
