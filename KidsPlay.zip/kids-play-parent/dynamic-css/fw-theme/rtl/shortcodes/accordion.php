/* Accordion RTL */
/* -------------------------------------------------- */
.rtl .fw-accordion .panel-title a:before {
  right: initial;
  left: 0;
}
