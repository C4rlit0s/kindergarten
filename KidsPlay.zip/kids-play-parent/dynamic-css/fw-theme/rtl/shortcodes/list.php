/* List */
/* -------------------------------------------------- */

.rtl .fw-list.list-icon i {
  left: initial;
  right: 8px;
}
