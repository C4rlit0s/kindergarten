/* Blockquote RTL */
/* -------------------------------------------------- */
.rtl blockquote.fw-quote-position {
  direction: <?php echo esc_js($the_core_less_variables['ltr-direction']); ?>;
}
