/* RTL Easy Slider */
/* -------------------------------------------------- */
.rtl .fw-easy-slider .fw-easy-slider-caption {
  right: -3%;
  left: initial;
}
.rtl .fw-easy-slider .fw-easy-slider-prev .fw-easy-slider-icon-left:before,
.rtl .fw-easy-slider .fw-easy-slider-next .fw-easy-slider-icon-left:before {
  content: '\f105';
}
.rtl .fw-easy-slider .fw-easy-slider-prev .fw-easy-slider-icon-right:before,
.rtl .fw-easy-slider .fw-easy-slider-next .fw-easy-slider-icon-right:before {
  content: '\f104';
}
.rtl .fw-easy-slider .fw-easy-slider-prev {
  left: initial;
  right: 30px;
}
.rtl .fw-easy-slider .fw-easy-slider-next {
  right: initial;
  left: 30px;
}
