/* RTL Widget Search */
/* -------------------------------------------------- */
.rtl .widget_search .search-submit {
  right: initial;
  left: 10px;
}
.rtl .widget_search label:after {
  right: initial;
  left: 10px;
}
