/* RTL Widget Login */
/* -------------------------------------------------- */
.rtl .fw-widget-login .forgetmenot {
  float: right;
}
.rtl .fw-widget-login .forget_password {
  float: left;
}
