/* RTL Widget Categories */
/* -------------------------------------------------- */
.rtl .widget_categories ul li a {
  display: inline-block;
}
.rtl .widget_categories ul li ul li:before {
  content: '\f149';
  margin-left: 20px;
  margin-right: 0;
}
