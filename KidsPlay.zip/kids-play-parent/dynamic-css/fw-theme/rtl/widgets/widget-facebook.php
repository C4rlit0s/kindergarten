/* RTL Widget Facebook */
/* -------------------------------------------------- */
.rtl .fw-widget-facebook .fw-btn-facebook a span:before {
  display: none;
}
.rtl .fw-widget-facebook .fw-btn-facebook a span:after {
  content: '\f09a';
  font-family: 'FontAwesome';
  font-style: normal;
  margin-left: 6px;
}
