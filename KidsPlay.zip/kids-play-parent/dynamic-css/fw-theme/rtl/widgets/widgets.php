/* RTL Widget */
/* -------------------------------------------------- */
.rtl .widget ul {
  padding-right: 0;
}
.rtl .widget .widget-title span,
.rtl .breadcrumbs span:last-child {
  padding-right: 0;
  padding-left: 10px;
}
