/* RTL Widget Post List */
/* -------------------------------------------------- */
.rtl .fw-side-posts-list li .fw-widget-post-image {
  float: right;
  margin: 0 0 10px 10px;
}
