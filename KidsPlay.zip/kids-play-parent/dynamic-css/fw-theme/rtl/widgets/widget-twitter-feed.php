/* RTL Widget Twitter */
/* -------------------------------------------------- */
.rtl .fw-widget-twitter .tweet-avatar {
  float: right;
  margin-left: 10px;
}
.rtl .fw-widget-twitter .fw-btn-tweet a span:before {
  display: none;
}
.rtl .fw-widget-twitter .fw-btn-tweet a span:after {
  content: '\f099';
  font-family: 'FontAwesome';
  font-style: normal;
  margin-left: 6px;
}
