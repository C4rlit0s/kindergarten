/* RTL Instagram Widget */
/* -------------------------------------------------- */
.rtl .flickr_badge_image,
.rtl .fw-instagram-wrap li {
  float: right;
  margin: 0 0 10px 10px;
}
/* Widget Instagram (add the icon in button)*/
.rtl .fw-widget-instagram .fw-btn-instagram span:before {
  display: none;
}
.rtl .fw-widget-instagram .fw-btn-instagram span:after {
  content: '\f16d';
  font-family: 'FontAwesome';
  font-style: normal;
  margin-left: 6px;
}
