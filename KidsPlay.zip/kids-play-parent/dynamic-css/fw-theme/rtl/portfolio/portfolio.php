/* RTL Portfolio */
/* -------------------------------------------------- */
.rtl .fw-portfolio .fw-portfolio-filter {
  direction: <?php echo esc_js($the_core_less_variables['ltr-direction']); ?>;
}
