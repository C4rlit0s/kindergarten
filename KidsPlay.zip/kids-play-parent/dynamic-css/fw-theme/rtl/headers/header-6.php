/* RTL Header Type 6 */
/* -------------------------------------------------- */
.rtl.header-6.header-align-left #header-menu {
  left: 0;
  right: auto;
}
.rtl.header-6.header-align-left.fw-logo-retina .fw-site-logo,
.rtl.header-6.header-align-left.fw-logo-no-retina .fw-site-logo {
  margin-right: auto;
  margin-left: 0;
}
.rtl.header-6.header-align-left .mm-listview > li > a i {
  margin-right: 0;
  margin-left: 10px;
}
