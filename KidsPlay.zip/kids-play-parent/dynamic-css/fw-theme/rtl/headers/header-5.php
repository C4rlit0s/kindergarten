/* RTL Header Type 5 */
/* -------------------------------------------------- */
.rtl.header-5  nav.mm-menu {
  direction: ltr;
}
