/* RTL Header Type 4 */
/* -------------------------------------------------- */
.rtl.header-4 .fw-wrap-logo {
  float: right;
}
.rtl.header-4 .fw-info-text-header-main {
  float: left;
}
.rtl.header-4 .fw-header-main .fw-container .fw-site-navigation > ul > li {
  float: right;
}
.rtl.header-4 .fw-header-main .primary-navigation > ul > li:first-child > a {
  margin-right: 0;
}
