/* RTL Post Type 1 */
/* -------------------------------------------------- */
.rtl .postlist .post footer.entry-meta .comments-link {
  float: left;
}
.rtl .postlist .fw-btn-post-read-more {
  float: right;
}
