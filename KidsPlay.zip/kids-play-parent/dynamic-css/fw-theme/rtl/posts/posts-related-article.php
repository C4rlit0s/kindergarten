/* RTL Post Related Artical */
/* -------------------------------------------------- */
.fw-wrap-related-article .fw-related-article-image {
  direction: <?php echo esc_js($the_core_less_variables['ltr-direction']); ?>;
}
