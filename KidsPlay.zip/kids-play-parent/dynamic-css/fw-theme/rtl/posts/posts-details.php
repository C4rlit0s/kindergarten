/* RTL Post Details */
/* -------------------------------------------------- */
.rtl .post-details .entry-header .wrap-entry-meta .cat-links {
  float: left;
}
.rtl .author-description .author-image {
  float: right;
}
.rtl .author-description .author-text {
  margin-left: 0;
  margin-right: 130px;
}
