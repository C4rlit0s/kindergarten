/* RTL  Image Block */
/* -------------------------------------------------- */
/* Image Position */
.rtl .fw-block-image-parent.fw-block-image-left {
  float: right;
  margin-left: 30px;
  margin-right: 0;
}
.rtl .fw-block-image-parent.fw-block-image-right {
  float: left;
  margin-right: 30px;
  margin-left: 0;
}
